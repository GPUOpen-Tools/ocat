var structNVAPI__D3D12__PSO__GEOMETRY__SHADER__DESC__V5 =
[
    [ "ConvertToFastGS", "structNVAPI__D3D12__PSO__GEOMETRY__SHADER__DESC__V5.html#a3146bb27d63cde1c6b4f10eefd67438d", null ],
    [ "DontUseViewportOrder", "structNVAPI__D3D12__PSO__GEOMETRY__SHADER__DESC__V5.html#a77a10d5d1364558003492488ab7dff6a", null ],
    [ "ForceFastGS", "structNVAPI__D3D12__PSO__GEOMETRY__SHADER__DESC__V5.html#a1b690e4f6a5793b2529a044647211ce1", null ],
    [ "NumCustomSemantics", "structNVAPI__D3D12__PSO__GEOMETRY__SHADER__DESC__V5.html#a916d9ae4c65b9a220beb46088cb0c435", null ],
    [ "OffsetRtIndexByVpIndex", "structNVAPI__D3D12__PSO__GEOMETRY__SHADER__DESC__V5.html#a06b6e2706cf615ec6905ef56288cedf8", null ],
    [ "pCoordinateSwizzling", "structNVAPI__D3D12__PSO__GEOMETRY__SHADER__DESC__V5.html#a4874fc33079662e96836a01000b215f7", null ],
    [ "pCustomSemantics", "structNVAPI__D3D12__PSO__GEOMETRY__SHADER__DESC__V5.html#af1b4867f942087e0bc063adfdd304e07", null ],
    [ "UseAttributeSkipMask", "structNVAPI__D3D12__PSO__GEOMETRY__SHADER__DESC__V5.html#a4f64126527b00580975a7a6ddd6e3254", null ],
    [ "UseCoordinateSwizzle", "structNVAPI__D3D12__PSO__GEOMETRY__SHADER__DESC__V5.html#a46f29001a9363cddfc5bd15fd211627f", null ],
    [ "UseSpecificShaderExt", "structNVAPI__D3D12__PSO__GEOMETRY__SHADER__DESC__V5.html#a20c85fd357761f30288afd3275bd5cd6", null ],
    [ "UseViewportMask", "structNVAPI__D3D12__PSO__GEOMETRY__SHADER__DESC__V5.html#a6515479d19da6311ecc6a7f40607f2b9", null ],
    [ "version", "structNVAPI__D3D12__PSO__GEOMETRY__SHADER__DESC__V5.html#af408f7c5339f5523afb669e41e428aae", null ]
];