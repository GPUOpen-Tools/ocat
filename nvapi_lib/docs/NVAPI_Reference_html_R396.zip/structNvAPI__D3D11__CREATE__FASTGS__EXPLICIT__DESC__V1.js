var structNvAPI__D3D11__CREATE__FASTGS__EXPLICIT__DESC__V1 =
[
    [ "flags", "structNvAPI__D3D11__CREATE__FASTGS__EXPLICIT__DESC__V1.html#aabb27a9565202e7944ee5a816e77e2f9", null ],
    [ "pCoordinateSwizzling", "structNvAPI__D3D11__CREATE__FASTGS__EXPLICIT__DESC__V1.html#a873051d44837157fdd1783c0f5ced9c3", null ],
    [ "version", "structNvAPI__D3D11__CREATE__FASTGS__EXPLICIT__DESC__V1.html#a8e57c30c960ff42166a7e0a357a3a6ab", null ]
];