var nvapi__lite__d3dext_8h =
[
    [ "NVAPI_DEVICE_FEATURE_LEVEL", "group__dx.html#ga102df4d23c307c4376d55946e6ede4e7", [
      [ "NVAPI_DEVICE_FEATURE_LEVEL_NULL", "group__dx.html#gga102df4d23c307c4376d55946e6ede4e7a3739d5bdb572928bd6c009eb8682dd54", null ],
      [ "NVAPI_DEVICE_FEATURE_LEVEL_10_0", "group__dx.html#gga102df4d23c307c4376d55946e6ede4e7a7b5e090f6932effbfa3ae4e726a2d25d", null ],
      [ "NVAPI_DEVICE_FEATURE_LEVEL_10_0_PLUS", "group__dx.html#gga102df4d23c307c4376d55946e6ede4e7ac4a9f67e8093c4cfbf38890a7d3eae72", null ],
      [ "NVAPI_DEVICE_FEATURE_LEVEL_10_1", "group__dx.html#gga102df4d23c307c4376d55946e6ede4e7a8e67486ed39b32f7389d941574645f5c", null ],
      [ "NVAPI_DEVICE_FEATURE_LEVEL_11_0", "group__dx.html#gga102df4d23c307c4376d55946e6ede4e7ad37d1fe8a46b71c5a0ede7f621e4118e", null ]
    ] ],
    [ "NvAPI_D3D11_CreateDevice", "group__dx.html#ga7d78220ab6b8e1fc3220c9023299a5f7", null ],
    [ "NvAPI_D3D11_CreateDeviceAndSwapChain", "group__dx.html#gafcfb2db180ab7b1b3250c73660663801", null ],
    [ "NvAPI_D3D11_SetDepthBoundsTest", "group__dx.html#ga0502f9d58555b662a3b6fcc9b61b7d2a", null ]
];