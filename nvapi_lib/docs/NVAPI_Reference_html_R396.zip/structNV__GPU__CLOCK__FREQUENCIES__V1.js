var structNV__GPU__CLOCK__FREQUENCIES__V1 =
[
    [ "bIsPresent", "structNV__GPU__CLOCK__FREQUENCIES__V1.html#a208523236ac0a32c110717325bc69f6a", null ],
    [ "domain", "structNV__GPU__CLOCK__FREQUENCIES__V1.html#a280a94c49734cdb37b6bc3f5ab068fad", null ],
    [ "frequency", "structNV__GPU__CLOCK__FREQUENCIES__V1.html#aac327997b4926488a136add7d6d72989", null ],
    [ "reserved", "structNV__GPU__CLOCK__FREQUENCIES__V1.html#afd9d1deb5921638d80104d2aaa8e90c4", null ],
    [ "version", "structNV__GPU__CLOCK__FREQUENCIES__V1.html#ae272205ccab1d963f48679dcb4a02cb9", null ]
];