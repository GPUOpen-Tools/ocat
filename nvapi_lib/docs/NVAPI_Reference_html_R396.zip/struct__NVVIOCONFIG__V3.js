var struct__NVVIOCONFIG__V3 =
[
    [ "fields", "struct__NVVIOCONFIG__V3.html#a7e0a75051e844ab089977f8baebdebd6", null ],
    [ "inConfig", "struct__NVVIOCONFIG__V3.html#a76eec78295d6f0326d97f0ef0954d571", null ],
    [ "nvvioConfigType", "struct__NVVIOCONFIG__V3.html#a9100125fdbc94721bca5c53a854e9a09", null ],
    [ "outConfig", "struct__NVVIOCONFIG__V3.html#ae33b19607a7da7033e3268bf5565bca9", null ],
    [ "version", "struct__NVVIOCONFIG__V3.html#ab9ef6c7aaff53df95367fc8c9ab973e0", null ],
    [ "vioConfig", "struct__NVVIOCONFIG__V3.html#ac6648d2cb216eb2ee4ec2e7f39cd6885", null ]
];