var structNvAPI__D3D11__CREATE__VERTEX__SHADER__EX__V3 =
[
    [ "NumCustomSemantics", "structNvAPI__D3D11__CREATE__VERTEX__SHADER__EX__V3.html#ad38357c617f51fb5373e916129f77685", null ],
    [ "pCustomSemantics", "structNvAPI__D3D11__CREATE__VERTEX__SHADER__EX__V3.html#a4a06290c8079dbcfb1f715a8c3c1d871", null ],
    [ "UseSpecificShaderExt", "structNvAPI__D3D11__CREATE__VERTEX__SHADER__EX__V3.html#aa870bcbf218806e6f113d5e10d50538d", null ],
    [ "UseWithFastGS", "structNvAPI__D3D11__CREATE__VERTEX__SHADER__EX__V3.html#a1e2107fe5da8a7bfd7755b4b596f1db9", null ],
    [ "version", "structNvAPI__D3D11__CREATE__VERTEX__SHADER__EX__V3.html#abe28b3ddb8149ea04ffebb265ea34ee1", null ]
];