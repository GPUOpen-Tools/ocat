var structNV__GPU__PERF__PSTATES20__PARAM__DELTA =
[
    [ "max", "structNV__GPU__PERF__PSTATES20__PARAM__DELTA.html#ab3ac87a374aedb15cc976e8eb92df56f", null ],
    [ "min", "structNV__GPU__PERF__PSTATES20__PARAM__DELTA.html#a7b86d610c090772cc858bac5e7ebe653", null ],
    [ "value", "structNV__GPU__PERF__PSTATES20__PARAM__DELTA.html#a07653ba935631aa1232dcf741818b78e", null ],
    [ "valueRange", "structNV__GPU__PERF__PSTATES20__PARAM__DELTA.html#ad6e66418838ca42d631888c5e6db7d2b", null ]
];