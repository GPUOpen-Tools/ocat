var structNvAPI__D3D11__CREATE__DOMAIN__SHADER__EX__V2 =
[
    [ "NumCustomSemantics", "structNvAPI__D3D11__CREATE__DOMAIN__SHADER__EX__V2.html#a0796f5c1e55e269edce022bb6fe95bc3", null ],
    [ "pCustomSemantics", "structNvAPI__D3D11__CREATE__DOMAIN__SHADER__EX__V2.html#ac04718fa5931e389e2676d3fddeb259d", null ],
    [ "UseWithFastGS", "structNvAPI__D3D11__CREATE__DOMAIN__SHADER__EX__V2.html#a338771ab4d7062f6590d980aef1dcc16", null ],
    [ "version", "structNvAPI__D3D11__CREATE__DOMAIN__SHADER__EX__V2.html#a966764e4aef22cb096de30dd7d4522d3", null ]
];