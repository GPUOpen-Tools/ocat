var structNVVIOTOPOLOGYTARGET =
[
    [ "hPhysicalGpu", "structNVVIOTOPOLOGYTARGET.html#a52b41a35d14d33f3206cefbc2b7324c2", null ],
    [ "hVioHandle", "structNVVIOTOPOLOGYTARGET.html#ab1f0243e537c394ba5ee4a4077917735", null ],
    [ "outputId", "structNVVIOTOPOLOGYTARGET.html#a502172b079178972a517cee92bd2db2d", null ],
    [ "vioId", "structNVVIOTOPOLOGYTARGET.html#a8a2c6efa830735561db61b7d65a58bdb", null ]
];