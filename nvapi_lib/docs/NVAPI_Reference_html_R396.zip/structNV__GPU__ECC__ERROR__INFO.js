var structNV__GPU__ECC__ERROR__INFO =
[
    [ "aggregate", "structNV__GPU__ECC__ERROR__INFO.html#a1dfc019a5333143a9c782b74d745eed1", null ],
    [ "current", "structNV__GPU__ECC__ERROR__INFO.html#aa3fd2a546dd94c6112ec2b29bc62de2f", null ],
    [ "doubleBitErrors", "structNV__GPU__ECC__ERROR__INFO.html#a4fff095cb14428dd04cb4feab250db8e", null ],
    [ "singleBitErrors", "structNV__GPU__ECC__ERROR__INFO.html#a6da06dde433aa1d8b8d63f7b5d86d2a1", null ],
    [ "version", "structNV__GPU__ECC__ERROR__INFO.html#aba5f279d433761d2c6ba1b15e23626eb", null ]
];