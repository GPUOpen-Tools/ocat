var structNV__DISPLAY__PATH__INFO__V3 =
[
    [ "count", "structNV__DISPLAY__PATH__INFO__V3.html#acd65c32fdc21e408c520912c2a6718fc", null ],
    [ "path", "structNV__DISPLAY__PATH__INFO__V3.html#ae19ab1d22c907518533db2023db80dc5", null ],
    [ "version", "structNV__DISPLAY__PATH__INFO__V3.html#a2a5ff69142b297ccf085d78a18e020a0", null ]
];