var struct__NVDRS__APPLICATION__V3 =
[
    [ "appName", "struct__NVDRS__APPLICATION__V3.html#a127a0417c00b2614cf054f0255a38818", null ],
    [ "fileInFolder", "struct__NVDRS__APPLICATION__V3.html#ad40bfe9a6c77911bfbde93ef26594039", null ],
    [ "isCommandLine", "struct__NVDRS__APPLICATION__V3.html#a453ed78b89185a9437a314d789eac6d1", null ],
    [ "isMetro", "struct__NVDRS__APPLICATION__V3.html#a23bb1efde731d29bc9e95860cfcea9e5", null ],
    [ "isPredefined", "struct__NVDRS__APPLICATION__V3.html#af3df9b9d202ad4da2fada0cb8bf1c122", null ],
    [ "launcher", "struct__NVDRS__APPLICATION__V3.html#a71019a25d7ee66be99750b71c9e29c54", null ],
    [ "reserved", "struct__NVDRS__APPLICATION__V3.html#a166b0d022c962a51081bb4771672f380", null ],
    [ "userFriendlyName", "struct__NVDRS__APPLICATION__V3.html#a793b8e11a654c841dbb56f82f5514bc8", null ],
    [ "version", "struct__NVDRS__APPLICATION__V3.html#ab4ec67084d5f16cfd782823e03e6b68e", null ]
];