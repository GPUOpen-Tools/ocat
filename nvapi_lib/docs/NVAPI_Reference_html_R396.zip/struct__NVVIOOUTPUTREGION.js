var struct__NVVIOOUTPUTREGION =
[
    [ "height", "struct__NVVIOOUTPUTREGION.html#acec6fb15fb6e1814da24fc11ba8885bc", null ],
    [ "width", "struct__NVVIOOUTPUTREGION.html#a2fc505c267c68bce1c1d2ff6733994e2", null ],
    [ "x", "struct__NVVIOOUTPUTREGION.html#a8622f8b6003b39821f22c082757ed765", null ],
    [ "y", "struct__NVVIOOUTPUTREGION.html#aae54062b4bcfb95955bdfe10f23c5726", null ]
];