var structNVAPI__ANSEL__CONFIGURATION__STRUCT__V1 =
[
    [ "hotkeyModifier", "structNVAPI__ANSEL__CONFIGURATION__STRUCT__V1.html#ad357de61e26dd964f0fc081da72a64ca", null ],
    [ "keyEnable", "structNVAPI__ANSEL__CONFIGURATION__STRUCT__V1.html#a081e3d1a597acbad9bd59863704aa975", null ],
    [ "numAnselFeatures", "structNVAPI__ANSEL__CONFIGURATION__STRUCT__V1.html#a8558635603a0d5598c3d85a60e3c264c", null ],
    [ "pAnselFeatures", "structNVAPI__ANSEL__CONFIGURATION__STRUCT__V1.html#ac2c7b2010328c1d0c721cd7cc1e1054f", null ],
    [ "version", "structNVAPI__ANSEL__CONFIGURATION__STRUCT__V1.html#a41276ff0ea2a26fd5e2063850f152c4d", null ]
];