var group__nvapi =
[
    [ "General NVAPI Functions", "group__nvapifunctions.html", "group__nvapifunctions" ],
    [ "General NVAPI Defines, Structs, and Enums", "group__nvapitypes.html", "group__nvapitypes" ],
    [ "NVAPI Handles", "group__nvapihandles.html", "group__nvapihandles" ],
    [ "NvAPI Status Values", "group__nvapistatus.html", "group__nvapistatus" ]
];