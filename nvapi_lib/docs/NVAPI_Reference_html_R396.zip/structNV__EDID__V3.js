var structNV__EDID__V3 =
[
    [ "EDID_Data", "structNV__EDID__V3.html#af8058440d7d30b1d41db32a7e7295f5e", null ],
    [ "edidId", "structNV__EDID__V3.html#a9544f60aa9499e59ea475c064600db59", null ],
    [ "offset", "structNV__EDID__V3.html#a4c64ff0b019e38cf0630cbb25af9cb87", null ],
    [ "sizeofEDID", "structNV__EDID__V3.html#abfe714a10c6333b95c65fd37cd3b59cc", null ],
    [ "version", "structNV__EDID__V3.html#ad871e9a8c5336bfe84614d5b30e60aae", null ]
];