var structNvGUID =
[
    [ "data1", "structNvGUID.html#ac8031b147c54f75c7fd6c5c15a3426cf", null ],
    [ "data2", "structNvGUID.html#a505dc34a8e0be806451749e3105a4c80", null ],
    [ "data3", "structNvGUID.html#a8a50076122400d933f19b4273ae10012", null ],
    [ "data4", "structNvGUID.html#a9fb7f295a3061760bb414361e6c1a1d1", null ]
];