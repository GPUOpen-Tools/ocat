var struct__NVVIOGAMMARAMP8 =
[
    [ "uBlue", "struct__NVVIOGAMMARAMP8.html#a8a85527cc91d1df07418f8a9bf22c12d", null ],
    [ "uGreen", "struct__NVVIOGAMMARAMP8.html#ae5d4fb477badabd4df8942eb7c97986c", null ],
    [ "uRed", "struct__NVVIOGAMMARAMP8.html#abe2a2ead2f6bc2fce402dc78157154ed", null ]
];