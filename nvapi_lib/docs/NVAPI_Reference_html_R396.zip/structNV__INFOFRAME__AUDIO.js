var structNV__INFOFRAME__AUDIO =
[
    [ "channelCount", "structNV__INFOFRAME__AUDIO.html#addee029686d33cf305e04ff8bf4ef43f", null ],
    [ "codingExtensionType", "structNV__INFOFRAME__AUDIO.html#a5f5717c25efe433ef92633bacb976a73", null ],
    [ "codingType", "structNV__INFOFRAME__AUDIO.html#a2f329d3a2e74669e7747f850bb9fc402", null ],
    [ "downmixInhibit", "structNV__INFOFRAME__AUDIO.html#ad01131e244cd0b06a51a8ca6949bc87f", null ],
    [ "Future10", "structNV__INFOFRAME__AUDIO.html#a7f941d2959918751debedade0b63b5c8", null ],
    [ "Future12", "structNV__INFOFRAME__AUDIO.html#accc7d1f9581e2e7d2702be4fceaec706", null ],
    [ "Future2x", "structNV__INFOFRAME__AUDIO.html#a1cf05b1b3d056df7cdd50ed98a12bb2a", null ],
    [ "Future3x", "structNV__INFOFRAME__AUDIO.html#a3d7af8933286cb7324507b8e76ea836c", null ],
    [ "Future52", "structNV__INFOFRAME__AUDIO.html#aa04136d79b7abd1fb5332edf399818c9", null ],
    [ "Future6", "structNV__INFOFRAME__AUDIO.html#adc7c7496a88fa1889ec0992e95cf17eb", null ],
    [ "Future7", "structNV__INFOFRAME__AUDIO.html#ac142516015347bbf80ab0a4aae01a5e4", null ],
    [ "Future8", "structNV__INFOFRAME__AUDIO.html#a0b1749d0681c2b4849db2a3218a9a89f", null ],
    [ "Future9", "structNV__INFOFRAME__AUDIO.html#a8316b2faeb4eb7311d6b7c2667b08db2", null ],
    [ "levelShift", "structNV__INFOFRAME__AUDIO.html#a00bdd7878b53197e1f34c00f0190bd80", null ],
    [ "lfePlaybackLevel", "structNV__INFOFRAME__AUDIO.html#aa0666f7c35eb05db5372a04d9e2ef428", null ],
    [ "sampleRate", "structNV__INFOFRAME__AUDIO.html#a084b889d1278e8f238b815bc6f96f5e8", null ],
    [ "sampleSize", "structNV__INFOFRAME__AUDIO.html#ac0c3d1b5ef83f0c762f0af1a1f72259d", null ],
    [ "speakerPlacement", "structNV__INFOFRAME__AUDIO.html#ae0da60033e9e3634a8c486bb9a2aafdf", null ]
];