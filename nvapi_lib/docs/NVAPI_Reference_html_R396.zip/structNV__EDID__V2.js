var structNV__EDID__V2 =
[
    [ "EDID_Data", "structNV__EDID__V2.html#ac00e363b849a33ece3d7829835ea0705", null ],
    [ "sizeofEDID", "structNV__EDID__V2.html#a461b12882e5a952153e11aed7890b163", null ],
    [ "version", "structNV__EDID__V2.html#acab4750addd06fcf4c91b3a987d5e6dd", null ]
];