var structNVAPI__D3D12__PSO__VERTEX__SHADER__DESC__V3 =
[
    [ "UseSpecificShaderExt", "structNVAPI__D3D12__PSO__VERTEX__SHADER__DESC__V3.html#a455b67b133a3a9d294412c8b4d89c6c6", null ]
];