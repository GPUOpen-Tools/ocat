var structNV__INFOFRAME__DATA =
[
    [ "audio", "structNV__INFOFRAME__DATA.html#a0b714853c4a56e45d9a3c41d05db7e07", null ],
    [ "cmd", "structNV__INFOFRAME__DATA.html#a919eecfe2b449f177d0ef23f46869bc0", null ],
    [ "infoframe", "structNV__INFOFRAME__DATA.html#a5e874a753cd1cef7db807da9e7a2660d", null ],
    [ "property", "structNV__INFOFRAME__DATA.html#ae52c05236985d33122e71f04ee155bc9", null ],
    [ "size", "structNV__INFOFRAME__DATA.html#aeb985eb73a236b787490329454fb697c", null ],
    [ "type", "structNV__INFOFRAME__DATA.html#a296d4af00495c5cf7d4f2cd268446870", null ],
    [ "version", "structNV__INFOFRAME__DATA.html#a318686b382ef2d0bd9b1c5d3a3299900", null ],
    [ "video", "structNV__INFOFRAME__DATA.html#a555e320a524c3850846a17c2ab9232b1", null ]
];