var struct__NVVIODATAFORMATDETAIL =
[
    [ "dataFormat", "struct__NVVIODATAFORMATDETAIL.html#a8037d1f294676aa176f2c50264044744", null ],
    [ "vioCaps", "struct__NVVIODATAFORMATDETAIL.html#a61b98e9b00a3c7eb7ab59893accd866c", null ]
];