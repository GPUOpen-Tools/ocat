var structNV__GPU__PERF__PSTATES20__INFO__V1 =
[
    [ "baseVoltages", "structNV__GPU__PERF__PSTATES20__INFO__V1.html#ace7d86f6c2499c7bc131ff19188f8b5e", null ],
    [ "bIsEditable", "structNV__GPU__PERF__PSTATES20__INFO__V1.html#a0746162936f6f7a263e3afbfe393ee14", null ],
    [ "clocks", "structNV__GPU__PERF__PSTATES20__INFO__V1.html#a3baf1b870d4955c3a3e6127916970482", null ],
    [ "numBaseVoltages", "structNV__GPU__PERF__PSTATES20__INFO__V1.html#a036510f727975913b5a69ee8477cf5ce", null ],
    [ "numClocks", "structNV__GPU__PERF__PSTATES20__INFO__V1.html#a6d53b87c30599033f093745cc762d8a0", null ],
    [ "numPstates", "structNV__GPU__PERF__PSTATES20__INFO__V1.html#abf0dbb9d09e72ab5c45b8517fd9fd911", null ],
    [ "pstateId", "structNV__GPU__PERF__PSTATES20__INFO__V1.html#a0796de15036a7d4f6e3711e88911e81e", null ],
    [ "pstates", "structNV__GPU__PERF__PSTATES20__INFO__V1.html#ae871d8f82bb220e5e05e0e642cd81a8a", null ],
    [ "reserved", "structNV__GPU__PERF__PSTATES20__INFO__V1.html#a58dbaa09f78f854e18562833457f590a", null ],
    [ "version", "structNV__GPU__PERF__PSTATES20__INFO__V1.html#a4d0d53d17c85d01d68c5f43cbc5d3051", null ]
];