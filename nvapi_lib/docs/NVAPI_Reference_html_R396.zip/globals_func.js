var globals_func =
[
    [ "_", "globals_func.html", null ],
    [ "d", "globals_func_d.html", null ],
    [ "n", "globals_func_n.html", null ]
];