var NAVTREE =
[
  [ "NVAPI Reference Documentation (Developer)", "index.html", [
    [ "NVIDIA NVAPI", "index.html", "index" ],
    [ "Legal Notice", "legal.html", null ],
    [ "Modules", "modules.html", "modules" ],
    [ "Data Structures", "annotated.html", [
      [ "Data Structures", "annotated.html", "annotated_dup" ],
      [ "Class Hierarchy", "hierarchy.html", "hierarchy" ],
      [ "Data Fields", "functions.html", [
        [ "All", "functions.html", "functions_dup" ],
        [ "Variables", "functions_vars.html", "functions_vars" ]
      ] ]
    ] ],
    [ "Files", null, [
      [ "File List", "files.html", "files" ],
      [ "Globals", "globals.html", [
        [ "All", "globals.html", "globals_dup" ],
        [ "Functions", "globals_func.html", "globals_func" ],
        [ "Variables", "globals_vars.html", null ],
        [ "Typedefs", "globals_type.html", "globals_type" ],
        [ "Enumerations", "globals_enum.html", "globals_enum" ],
        [ "Enumerator", "globals_eval.html", "globals_eval" ],
        [ "Macros", "globals_defs.html", "globals_defs" ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"NvApiDriverSettings_8h.html",
"NvApiDriverSettings_8h.html#a49f32517cce0158eb041adc81536cbffa08440c1d4f637b2ee3ef2e03893ff97f",
"NvApiDriverSettings_8h.html#a8e75c074b5528d10e3e021b2d595719ca76da7fdf5225c5d78f0e64c0801692cb",
"NvApiDriverSettings_8h.html#abe0a4a1603e82096f3bb0f6b257c390ba31e522417e09a7543a7a1d32fe9ea28a",
"globals_b.html",
"group__dispcontrol.html#gae160816561d8f76661c69bfde5354435",
"group__drsapi.html#ga685de9b433119d1286fda5afa8da6f74",
"group__dx.html#gaf5ad712e159c79512652c5ec353294c7",
"group__gpu.html#ga66881bf5ea741d1bcd2d7dd6bef62087",
"group__gpu.html#gga6e41a8ec867ab3758a47cc8648fe060faa97d07ca45d1f3b5224556c89997f99d",
"group__gputhermal.html#ggab812f82cf76686053dccedbdb63cd077aca5f26c44f749b4f7b506700d6197cdb",
"group__mosaicapi.html#ggadcda654b222004e34299b8ef6de07d27a7cd854624b8eea5aab8787e259e813e3",
"group__nvapistatus.html#gga12534f3b520256799842c0172e9afdf7a9c7625559b23ea6bc2c2e9c79aec5452",
"group__oglapi.html#gadf2e4f4b284dd861147cff98842be4b4",
"group__tvapi.html#ggabb0e56ec888f3577457bedb79e4fa195a80ce438ad7c795e2689d71b58984881d",
"group__vidio.html#gaf656119bb5005141aeecea816eab6eb9",
"nvHLSLExtns_8h.html#a55b359c4a2402b4da478ea7a4915abee",
"nvapi_8h.html#a2d6c7124d7d523652a4d67c5844823fd",
"nvapi_8h.html#a7332ab312f6313e8ee1597bfc5c43886",
"nvapi_8h.html#aaf4307f68f29c80be835f7b7c2a6e1eea522a7c87447ab8e549233919d7741a07",
"nvapi_8h.html#ga5485dd3b5aa6e790493a44b339d171aaae9213c82d76050bfe3e15d242d2694d8",
"nvapi__lite__salstart_8h.html#a99020bff3b7892fff07cb7b6ceb50ea4",
"structNV__CHIPSET__INFO__v1.html#a54a82ea7853106c517ef4fa18128685e",
"structNV__GPU__THERMAL__SETTINGS__V1.html#a7b5732d5bae366ef7b298332341e1516",
"structNvAPI__D3D11__CREATE__HULL__SHADER__EX__V2.html#a495fdb3cfb1e4e0ac91f58e83d620d3e",
"struct__NVVIOINPUTCONFIG.html#a930adde7a5bad72d2c8acab4baa5cb05",
"struct__NV__DISPLAYCONFIG__SOURCE__MODE__INFO__V1.html#a857cee56f403bc50ed10e1d708bb1e9a",
"struct__NV__HDR__COLOR__DATA__V1.html#a487c9cef48826e19552d517fd3907909",
"struct__NV__SMP__ASSIST__INITIALIZE__PARAMS__V1.html"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';