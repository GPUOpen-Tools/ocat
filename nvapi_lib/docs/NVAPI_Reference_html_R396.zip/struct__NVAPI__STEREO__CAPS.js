var struct__NVAPI__STEREO__CAPS =
[
    [ "reserved", "struct__NVAPI__STEREO__CAPS.html#a76ce38b97871946411b7b168adf16c93", null ],
    [ "reserved2", "struct__NVAPI__STEREO__CAPS.html#a268f5fdae8805f26bb8ccfcc74c38b9a", null ],
    [ "supportsWindowedModeAutomatic", "struct__NVAPI__STEREO__CAPS.html#ac4d167ac1842f86c17688511734a1479", null ],
    [ "supportsWindowedModeOff", "struct__NVAPI__STEREO__CAPS.html#a9ac8c7236064d966663e45a34b07b610", null ],
    [ "supportsWindowedModePersistent", "struct__NVAPI__STEREO__CAPS.html#a8244a65307a363021c2bf8e0166d433f", null ],
    [ "version", "struct__NVAPI__STEREO__CAPS.html#a8a095855f36c3ea5f71429581bf69bfa", null ]
];