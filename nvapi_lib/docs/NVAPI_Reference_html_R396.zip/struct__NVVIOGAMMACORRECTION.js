var struct__NVVIOGAMMACORRECTION =
[
    [ "fGammaValueB", "struct__NVVIOGAMMACORRECTION.html#a5da9f274f04ac4364a7ce5f265b6cd4b", null ],
    [ "fGammaValueG", "struct__NVVIOGAMMACORRECTION.html#aee8cb623cede14af6b1103bac042b404", null ],
    [ "fGammaValueR", "struct__NVVIOGAMMACORRECTION.html#a44c7fac14d5722865b5fc59dffab3993", null ],
    [ "gammaRamp", "struct__NVVIOGAMMACORRECTION.html#a3d6614d4d71da801224446527d9ccb3d", null ],
    [ "gammaRamp10", "struct__NVVIOGAMMACORRECTION.html#a0f4aaff76fea7e7e703f9ffe6a9e7541", null ],
    [ "gammaRamp8", "struct__NVVIOGAMMACORRECTION.html#aa73c0bf6bb2339cd4505c43ba60fbc9b", null ],
    [ "version", "struct__NVVIOGAMMACORRECTION.html#ad6aae2ed845924bc65694110852c96ba", null ],
    [ "vioGammaCorrectionType", "struct__NVVIOGAMMACORRECTION.html#a2f4960f088d99a8e2c6c7c6132b98e4f", null ]
];