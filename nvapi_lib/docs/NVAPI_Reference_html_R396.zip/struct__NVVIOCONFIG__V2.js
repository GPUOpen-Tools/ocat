var struct__NVVIOCONFIG__V2 =
[
    [ "fields", "struct__NVVIOCONFIG__V2.html#a6764316447ec3117fdf18b53e59473fe", null ],
    [ "inConfig", "struct__NVVIOCONFIG__V2.html#a0dd26eb275141d12444bcd8cd65a021e", null ],
    [ "nvvioConfigType", "struct__NVVIOCONFIG__V2.html#a86a925e6d1f47d242241ac5f42226564", null ],
    [ "outConfig", "struct__NVVIOCONFIG__V2.html#aaa5c6e2d6a149d9b92f7d752891ee6d1", null ],
    [ "version", "struct__NVVIOCONFIG__V2.html#adc15efb6c77772e8f91a17faf48ff415", null ],
    [ "vioConfig", "struct__NVVIOCONFIG__V2.html#a3d19294b21f25333cfdb3c3514e749f3", null ]
];