var structNV__GPU__ECC__STATUS__INFO =
[
    [ "configurationOptions", "structNV__GPU__ECC__STATUS__INFO.html#ab63f62fcaf6270b96f1421ed9a077c62", null ],
    [ "isEnabled", "structNV__GPU__ECC__STATUS__INFO.html#aac22114b9692bbda8d1faf42ef03383f", null ],
    [ "isSupported", "structNV__GPU__ECC__STATUS__INFO.html#a5a27361a92c896ed8a84431e6a3fd07c", null ],
    [ "version", "structNV__GPU__ECC__STATUS__INFO.html#af0ac66e25601921762df999199fdad63", null ]
];